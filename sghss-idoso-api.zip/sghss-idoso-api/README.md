# sghss-idoso-api

API REST (Node.js/Express) para suporte ao cuidado do idoso no contexto de um SGHSS, com **PostgreSQL**, **Prisma**, **JWT**, **bcrypt**, **Zod** e **Swagger/OpenAPI**.

## Requisitos
- Node.js LTS
- PostgreSQL

## Configuração
1) Instale dependências:
```bash
npm install
```

2) Configure variáveis de ambiente:
```bash
cp .env.example .env
# edite o .env
```

3) Crie o banco no PostgreSQL (ex.: `sghss_idoso`) e rode migrations:
```bash
npm run prisma:migrate
```

4) Inicie o servidor:
```bash
npm run dev
# ou: npm start
```

## Documentação (Swagger)
Após iniciar:
- Swagger UI: `http://localhost:3000/docs`

## Testes (Postman/Insomnia)
Fluxo mínimo sugerido:
1) `POST /auth/signup` (criar usuário)
2) `POST /auth/login` (pegar token)
3) Use `Authorization: Bearer <token>`
4) `POST /pacientes` (criar paciente)
5) `POST /consultas` (agendar consulta)
6) `POST /prontuarios` (registrar prontuário)
7) `POST /prescricoes` (emitir prescrição)

## Observação sobre permissões
- Perfis: `ADMIN`, `PROFISSIONAL`, `PACIENTE`, `CUIDADOR`
- Algumas rotas exigem `ADMIN/PROFISSIONAL`.
- Paciente e cuidador podem ler dados quando houver vínculo.

## Licença
Uso acadêmico.
